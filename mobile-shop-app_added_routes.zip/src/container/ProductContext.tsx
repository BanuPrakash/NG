import React, {useEffect, useState } from "react";
import Product from "../model/Product";
import axios from 'axios';

type ContextType = {
    products: Product[],
    handleDetail: (id: number) => Product | null
}

type Props = {
    children: React.ReactNode
}

const ProductContext = React.createContext<ContextType>({
    products: [],
    handleDetail: () => { return null; }
});

const ProductProvider = (props: Props) => {
    let [products, setProducts] = useState<Product[]>([]);
    useEffect(() => {
        axios.get("http://localhost:1234/products")
            .then(response => {
                setProducts(response.data);
            })
    }, []);

    function handleDetail(id: number): Product {
        let prd: Product = products.find(p => p.productId === id)!;
        return prd;

    }
    return (
        <ProductContext.Provider value={{ products, handleDetail }}>
            {props.children}
        </ProductContext.Provider>
    )
}

export {ProductContext, ProductProvider}