import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import App from './App';
import {ProductProvider} from './container/ProductContext';

import 'bootstrap/dist/css/bootstrap.min.css';
import { CartProvider } from './container/CartContext';
const root = ReactDOM.createRoot(
  document.getElementById('root') as HTMLElement
);
root.render(
  
    <ProductProvider>
      <CartProvider>
      <App />
      </CartProvider>
    </ProductProvider>
  
);
