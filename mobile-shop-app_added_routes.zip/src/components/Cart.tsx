import { useContext } from "react";
import { CartContext } from "../container/CartContext";
import CartList from "./CartList";

const Cart = () => {
	let {cart} = useContext(CartContext)
	return <div className="container">
		{
		cart.map(product => <CartList  product={product} key = {product.id}/>)
		}
	</div>
}

export default Cart;