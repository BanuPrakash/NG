import { useContext } from 'react';
import { ProductContext } from '../container/ProductContext';
import ProductRow from './ProductCard';

const ProductList = () => {
    let {products} = useContext(ProductContext);
    return <div className="container">
        <div className="row">
                {
                    products.map(p => <ProductRow product={p} key={p.productId}/>)
                }
        </div>
    </div>
}

export default ProductList;