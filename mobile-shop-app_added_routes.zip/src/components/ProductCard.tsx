import { faShoppingCart, faHeart } from '@fortawesome/free-solid-svg-icons';
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { useContext } from 'react';
import { CartContext } from '../container/CartContext';
import Product from '../model/Product';
type Props = {
    product:Product
}
const ProductRow =  ({product}: Props) => {
    let {addToCart} = useContext(CartContext);
    return   <div className="item col-md-4 mr-2">
    <div className="mb-r">
        <div className="card card-cascade wider">
            <a>
                <div className="view overlay hm-white-slight">
                    <img src={product.productImageUrl} className="img-fluid" alt="" width="360px" height="640px" />
                </div>
            </a>
            <div className="card-body text-center no-padding">
                <p className="card-title">
                    <strong>
                        <a>{product.productSeller}</a>
                    </strong>
                </p>
                <p className="card-text">{product.productDescription}</p>
                <div className="card-footer">
                    <span className="left">₹ {product.productPrice}</span>
                    <span className="right px-2">
                        
                        <FontAwesomeIcon icon={faHeart} color="red" className='px-3'/>
                        <FontAwesomeIcon icon={faShoppingCart} onClick={() => addToCart(product.productId)} color="blue"/>
                        
                    </span>
                </div>
            </div>

        </div>
    </div>
</div>
}

export default ProductRow;