import { useContext } from "react";
import { Button } from "react-bootstrap";
import { CartContext } from "../container/CartContext";
import { Cart } from "../reducers/CartReducer";

type Props = {
	product:Cart
}

const CartList = ({product}:Props) => {
	let {increment} = useContext(CartContext);
	return <div className="row">
		<div className="col-md-2">
			<img src={product.image} style={{"width": "50px", height:"50px"} } />
			{product.name}
		</div>
		<div className="col-md-6 text-center">
			<Button  variant="outline-primary" onClick={()=>increment(product.id)}>+</Button>
                Qty: {product.qty}
			<Button  variant="outline-primary">-</Button>
		</div>
		<div className="col-md-2">
			Price: ₹ {product.price}
		</div>
		<div className="col-md-2">
			Amount: ₹ {product.amount}
		</div>
		
	</div>
}

export default CartList;