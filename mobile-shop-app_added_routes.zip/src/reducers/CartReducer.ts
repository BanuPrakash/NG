
// action has type and payload
import Product from "../model/Product";

type Action = {type:'ADD_TO_CART', payload:Product} 
| {type:'REMOVE_FROM_CART', payload:number}
| {type:'INCREMENT', payload:number}

export interface Cart {
  id: number;
  name: string;
  price: number;
  image: string;
  qty:number;
  amount:number;
}
export interface StateType {
    products: Cart[],
    total:number
}

const CartReducer = (state:StateType, action:Action) => {
    if(action.type === 'ADD_TO_CART') {
        const product = {...action.payload};
        let item = {
            id:product.productId,
            name:product.productDescription,
            image: product.productImageUrl,
            price:product.productPrice,
            qty: 1,
            amount: product.productPrice
        }
        let cartItems = state.products;
        let total:number = state.total += item.amount;
        return {products: [...cartItems, {...item}], total};

    } else if (action.type === 'INCREMENT') {
       let products = state.products;
       products.forEach(product => {
        if(product.id === action.payload) {
            product.qty++;
            product.amount = product.price * product.qty;
        }
       });
       let total:number = products.map(p => p.amount).reduce((i1,i2) => i1 + i2, 0.0);
       return {products, total}
    } else {
        return state;
    }
}


export default CartReducer;